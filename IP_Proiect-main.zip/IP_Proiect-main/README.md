# IP_Proiect
Aplicatia de tip food delivery are scopul de a facilita plasarea comenzilor livrabile prin curier, de la diferite restaurante. Meniul este preluat de la fiecare restaurant astfel incat cei care folosesc aplicatia sa poata plasa sau sterge comezni. Dupa ce comanda a fost preluata, curierul se va loga in contul aplicatiei si va primi informatii cu privire la ce va trebui sa livreze.
